export default function HeroBanner() {
  return (
    <section className="relative h-64 bg-cover bg-center" style={{ backgroundImage: 'url(https://wallpaperaccess.com/full/3678517.jpg)' }}>
      <div className="bg-black bg-opacity-50 h-full flex flex-col justify-center items-center text-white">
        <h2 className="text-3xl font-bold mb-4">Watch the Latest Episodes Now</h2>
        <button className="bg-primary px-6 py-2 rounded text-white">Start Watching</button>
      </div>
    </section>
  );
}