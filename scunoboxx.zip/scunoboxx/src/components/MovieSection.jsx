export default function MovieSection({ title }) {
  return (
    <section className="p-4">
      <h3 className="text-xl font-bold mb-4">{title}</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="bg-gray-100 rounded shadow">
            <img src={`https://placehold.co/200x300?text=Anime+${i + 1}`} alt="" className="rounded-t" />
            <div className="p-2">
              <h4 className="font-semibold text-sm">Anime Title {i + 1}</h4>
              <p className="text-xs text-gray-600">Sub | 12 eps</p>
              <button className="text-primary text-xs mt-1">Watch Now</button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}