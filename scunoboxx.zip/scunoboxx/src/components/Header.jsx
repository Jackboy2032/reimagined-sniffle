export default function Header() {
  return (
    <header className="flex justify-between items-center p-4 bg-primary text-white shadow-md">
      <h1 className="text-2xl font-bold">ScunoBoxx</h1>
      <nav className="flex gap-6">
        <a href="#">Home</a>
        <a href="#">Series</a>
        <a href="#">Movies</a>
        <a href="#">Genres</a>
      </nav>
      <div className="flex gap-4">
        <input type="text" placeholder="Search..." className="px-2 py-1 rounded" />
        <button className="bg-white text-primary px-3 py-1 rounded">Login</button>
      </div>
    </header>
  );
}