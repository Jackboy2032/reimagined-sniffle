import Header from "./components/Header";
import HeroBanner from "./components/HeroBanner";
import MovieSection from "./components/MovieSection";

export default function App() {
  return (
    <div className="bg-white text-black min-h-screen">
      <Header />
      <HeroBanner />
      <MovieSection title="Trending Now" />
      <MovieSection title="New Releases" />
    </div>
  );
}